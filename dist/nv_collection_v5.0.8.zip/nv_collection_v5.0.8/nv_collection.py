"""A project collection manager plugin for novelyst.

Requires Python 3.6+
Copyright (c) 2023 Peter Triesberger
For further information see https://github.com/peter88213/nv_collection
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import sys
import tkinter as tk
import os
from pathlib import Path
import webbrowser
import gettext
import locale

__all__ = ['Error',
           '_',
           'norm_path',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'APPLICATION',
           'PLUGIN',
           'SERIES_PREFIX',
           'BOOK_PREFIX',
           ]


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_collection', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Collection')
PLUGIN = f'{APPLICATION} plugin v5.0.8'
SERIES_PREFIX = 'sr'
BOOK_PREFIX = 'bk'


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)

from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk
from tkinter import ttk


class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        return self.get('1.0', 'end').strip(' \n')

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self):
        value = super().get()
        if value == '':
            value = None
        return value


class IndexCard(tk.Frame):

    def __init__(self, master=None, cnf={}, fg='black', bg='white', font=None, scrollbar=True, **kw):
        super().__init__(master=master, cnf=cnf, **kw)
        self.title = MyStringVar(value='')
        self.titleEntry = tk.Entry(self,
                              bg=bg,
                              bd=0,
                              textvariable=self.title,
                              relief='flat',
                              font=font,
                              )
        self.titleEntry.config({'background': bg,
                           'foreground': fg,
                           'insertbackground': fg,
                           })
        self.titleEntry.pack(fill='x', ipady=6)

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(self,
                scrollbar=scrollbar,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                padx=5,
                pady=5,
                bg=bg,
                fg=fg,
                insertbackground=fg,
                font=font,
                )
        self.bodyBox.pack(fill='both', expand=True)

    def lock(self):
        self.titleEntry.config(state='disabled')
        self.bodyBox.config(state='disabled')

    def unlock(self):
        self.titleEntry.config(state='normal')
        self.bodyBox.config(state='normal')
import re
from html import unescape
import xml.etree.ElementTree as ET
import tkinter.font as tkFont



def indent(elem, level=0):
    i = f'\n{level * "  "}'
    if elem:
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def create_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'




class Series:

    def __init__(self):
        self.title = None
        self.desc = None


class Book:

    def __init__(self, filePath):
        self.filePath = filePath
        self.title = None
        self.desc = None

    def pull_metadata(self, novel):
        modified = False
        if self.title != novel.title:
            self.title = novel.title
            modified = True
        if self.desc != novel.desc:
            self.desc = novel.desc
            modified = True
        return modified

    def push_metadata(self, novel):
        modified = False
        if novel.title != self.title:
            novel.title = self.title
        if novel.desc != self.desc:
            novel.desc = self.desc
            modified = True
        return modified



class Collection:
    MAJOR_VERSION = 1
    MINOR_VERSION = 0

    XML_HEADER = '''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE COLLECTION SYSTEM "nvcx_1_0.dtd">
<?xml-stylesheet href="collection.css" type="text/css"?>
'''

    EXTENSION = 'nvcx'

    def __init__(self, filePath, tree):
        self.title = None
        self.tree = tree
        fontSize = tkFont.nametofont('TkDefaultFont').actual()['size']
        self.tree.tag_configure('SERIES', font=('', fontSize, 'bold'))

        self.books = {}

        self.series = {}

        self._filePath = None

        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        if filePath.lower().endswith(self.EXTENSION):
            self._filePath = filePath
            self.title, __ = os.path.splitext(os.path.basename(self.filePath))

    def read(self):

        def get_book(parent, xmlBook):
            bkId = xmlBook.attrib[('id')]
            xmlPath = xmlBook.find('Path')
            if xmlPath is not None:
                bookPath = xmlPath.text
                if bookPath and os.path.isfile(bookPath):
                    self.books[bkId] = Book(bookPath)
                    xmlTitle = xmlBook.find('Title')
                    if xmlTitle is not None and xmlTitle.text:
                        self.books[bkId].title = xmlTitle.text
                    else:
                        self.books[bkId].title = f"{_('Untitled')} ({bkId})"
                    xmlDesc = xmlBook.find('Desc')
                    if xmlDesc is not None:
                        paragraphs = []
                        for xmlParagraph in xmlDesc.iterfind('p'):
                            if xmlParagraph.text:
                                paragraphs.append(xmlParagraph.text)
                        self.books[bkId].desc = '\n'.join(paragraphs)
                        self.tree.insert(parent, 'end', bkId, text=self.books[bkId].title, open=True)

        xmlTree = ET.parse(self.filePath)
        xmlRoot = xmlTree.getroot()
        if not xmlRoot.tag == 'COLLECTION':
            raise Error(f'{_("No collection found in file")}: "{norm_path(self.filePath)}".')

        try:
            majorVersionStr, minorVersionStr = xmlRoot.attrib['version'].split('.')
            majorVersion = int(majorVersionStr)
            minorVersion = int(minorVersionStr)
        except:
            raise Error(f'{_("No valid version found in file")}: "{norm_path(self.filePath)}".')

        if majorVersion > self.MAJOR_VERSION:
            raise Error(_('The collection was created with a newer plugin version.'))

        elif majorVersion < self.MAJOR_VERSION:
            raise Error(_('The collection was created with an outdated plugin version.'))

        elif minorVersion > self.MINOR_VERSION:
            raise Error(_('The collection was created with a newer plugin version.'))

        self.reset_tree()
        self.books = {}
        self.series = {}
        for xmlElement in xmlRoot:
            if xmlElement.tag == 'BOOK':
                get_book('', xmlElement)
            elif xmlElement.tag == 'SERIES':
                srId = xmlElement.attrib['id']
                self.series[srId] = Series()
                xmlTitle = xmlElement.find('Title')
                if xmlTitle is not None and xmlTitle.text:
                    self.series[srId].title = xmlTitle.text
                else:
                    self.series[srId].title = f"{_('Untitled')} ({srId})"
                xmlDesc = xmlElement.find('Desc')
                if xmlDesc is not None:
                    paragraphs = []
                    for xmlParagraph in xmlDesc.iterfind('p'):
                        if xmlParagraph.text:
                            paragraphs.append(xmlParagraph.text)
                    self.series[srId].desc = '\n'.join(paragraphs)
                self.tree.insert('', 'end', srId, text=self.series[srId].title, tags='SERIES', open=True)
                for xmlBook in xmlElement.iter('BOOK'):
                    get_book(srId, xmlBook)
        if not xmlRoot.attrib.get('version', None):
            self.write()
        return f'{len(self.books)} Books found in "{norm_path(self.filePath)}".'

    def write(self):

        def walk_tree(node, xmlNode):
            for elementId in self.tree.get_children(node):
                if elementId.startswith(BOOK_PREFIX):
                    xmlBook = ET.SubElement(xmlNode, 'BOOK')
                    xmlBook.set('id', elementId)
                    xmlBookTitle = ET.SubElement(xmlBook, 'Title')
                    if self.books[elementId].title:
                        xmlBookTitle.text = self.books[elementId].title
                    if self.books[elementId].desc:
                        xmlBookDesc = ET.SubElement(xmlBook, 'Desc')
                        for paragraph in self.books[elementId].desc.split('\n'):
                            ET.SubElement(xmlBookDesc, 'p').text = paragraph.strip()
                    xmlBookPath = ET.SubElement(xmlBook, 'Path')
                    xmlBookPath.text = self.books[elementId].filePath
                elif elementId.startswith(SERIES_PREFIX):
                    xmlSeries = ET.SubElement(xmlNode, 'SERIES')
                    xmlSeries.set('id', elementId)
                    xmlSeriesTitle = ET.SubElement(xmlSeries, 'Title')
                    if self.series[elementId].title:
                        xmlSeriesTitle.text = self.series[elementId].title
                    if self.series[elementId].desc:
                        xmlSeriesDesc = ET.SubElement(xmlSeries, 'Desc')
                        for paragraph in self.series[elementId].desc.split('\n'):
                            ET.SubElement(xmlSeriesDesc, 'p').text = paragraph.strip()
                    walk_tree(elementId, xmlSeries)

        xmlRoot = ET.Element('COLLECTION')
        xmlRoot.set('version', f'{self.MAJOR_VERSION}.{self.MINOR_VERSION}')
        walk_tree('', xmlRoot)

        indent(xmlRoot)
        xmlTree = ET.ElementTree(xmlRoot)
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            xmlTree.write(self.filePath, encoding='utf-8')

            self._postprocess_xml_file(self.filePath)
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

        return f'"{norm_path(self.filePath)}" written.'

    def add_book(self, book, parent='', index='end'):
        if os.path.isfile(book.filePath):
            for bkId in self.books:
                if book.filePath == self.books[bkId].filePath:
                    return None

            bkId = create_id(self.books, prefix=BOOK_PREFIX)
            self.books[bkId] = Book(book.filePath)
            self.books[bkId].pull_metadata(book.novel)
            self.tree.insert(parent, index, bkId, text=self.books[bkId].title, open=True)
            return bkId

        else:
            raise Error(f'"{norm_path(book.filePath)}" not found.')

    def remove_book(self, bkId):
        bookTitle = bkId
        try:
            bookTitle = self.books[bkId].title
            del self.books[bkId]
            self.tree.delete(bkId)
            message = f'Book "{bookTitle}" removed from the collection.'
            return message
        except:
            raise Error(f'Cannot remove "{bookTitle}".')

    def add_series(self, seriesTitle, index='end'):
        srId = create_id(self.series, prefix=SERIES_PREFIX)
        self.series[srId] = Series()
        self.series[srId].title = seriesTitle
        self.tree.insert('', index, srId, text=self.series[srId].title, tags='SERIES', open=True)

    def remove_series(self, srId):
        seriesTitle = self.series[srId].title
        for bookNode in self.tree.get_children(srId):
            self.tree.move(bookNode, '', 'end')
        del(self.series[srId])
        self.tree.delete(srId)
        return f'"{seriesTitle}" series removed from the collection.'

        raise Error(f'Cannot remove "{seriesTitle}" series from the collection.')

    def remove_series_with_books(self, srId):
        seriesTitle = self.series[srId].title
        for bkId in self.tree.get_children(srId):
            del self.books[bkId]
        del(self.series[srId])
        self.tree.delete(srId)
        return f'"{seriesTitle}" series removed from the collection.'

        raise Error(f'Cannot remove "{seriesTitle}" series from the collection.')

    def _postprocess_xml_file(self, filePath):
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(f'{self.XML_HEADER}{text}')
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

    def reset_tree(self):
        for child in self.tree.get_children(''):
            self.tree.delete(child)

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)

SETTINGS = dict(
    last_open='',
    tree_width='300',
)
OPTIONS = {}


class CollectionManager(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, ui, position, configDir):
        self._ui = ui
        super().__init__()

        self.iniFile = f'{configDir}/collection.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)

        self.title(PLUGIN)
        self._statusText = ''

        self.geometry(position)
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.mainWindow = ttk.Frame(self)
        self.mainWindow.pack(fill='both', padx=2, pady=2, expand=True)

        self.treeWindow = ttk.Panedwindow(self.mainWindow, orient='horizontal')
        self.treeWindow.pack(fill='both', expand=True)

        self.collection = None
        self._fileTypes = [(_('novelyst collection'), Collection.EXTENSION)]

        self.treeView = ttk.Treeview(self.treeWindow, selectmode='browse')
        scrollY = ttk.Scrollbar(self.treeView, orient='vertical', command=self.treeView.yview)
        self.treeView.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self.treeView.pack(side='left')
        self.treeWindow.add(self.treeView)
        self.treeView.bind('<<TreeviewSelect>>', self._on_select_node)
        self.treeView.bind('<<TreeviewSelect>>', self._on_select_node)
        self.treeView.bind('<Double-1>', self._open_book)
        self.treeView.bind('<Return>', self._open_book)
        self.treeView.bind('<Delete>', self._remove_node)
        self.treeView.bind('<Shift-Delete>', self._remove_series_with_books)
        self.treeView.bind('<Alt-B1-Motion>', self._move_node)

        self.indexCard = IndexCard(self.treeWindow, bd=2, relief='ridge')
        self.indexCard.pack(side='right')
        self.treeWindow.add(self.indexCard)

        self.treeWindow.update()
        self.treeWindow.sashpos(0, self.kwargs['tree_width'])

        self.statusBar = tk.Label(self, text='', anchor='w', padx=5, pady=2)
        self.statusBar.pack(expand=False, fill='both')

        self.pathBar = tk.Label(self, text='', anchor='w', padx=5, pady=3)
        self.pathBar.pack(expand=False, fill='both')

        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        self.fileMenu.add_command(label=_('New'), command=self._new_collection)
        self.fileMenu.add_command(label=_('Open...'), command=lambda: self._open_collection(''))
        self.fileMenu.add_command(label=_('Close'), command=self._close_collection)
        self.fileMenu.entryconfig(_('Close'), state='disabled')
        self.fileMenu.add_command(label=_('Exit'), accelerator=self._KEY_QUIT_PROGRAM[1], command=self.on_quit)

        self.seriesMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Series'), menu=self.seriesMenu)
        self.seriesMenu.add_command(label=_('Add'), command=self._add_series)
        self.seriesMenu.add_command(label=_('Remove selected series but keep the books'), command=self._remove_series)
        self.seriesMenu.add_command(label=_('Remove selected series and books'), command=self._remove_series_with_books)

        self.bookMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Book'), menu=self.bookMenu)
        self.bookMenu.add_command(label=_('Add current project to the collection'), command=self._add_current_project)
        self.bookMenu.add_command(label=_('Remove selected book from the collection'), command=self._remove_book)
        self.bookMenu.add_command(label=_('Update book data from the current project'), command=self._update_book)

        self.bind('<Escape>', self._restore_status)

        self.isModified = False
        self._element = None
        self._nodeId = None
        if self._open_collection(self.kwargs['last_open']):
            self.isOpen = True


    def on_quit(self, event=None):
        self._get_element_view()
        self.kwargs['tree_width'] = self.treeWindow.sashpos(0)

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)
        try:
            if self.collection is not None:
                if self.isModified:
                    self.collection.write()
        except Exception as ex:
            self._show_info(str(ex))
        finally:
            self.destroy()
            self.isOpen = False

    def _on_select_node(self, event=None):
        self._get_element_view()
        try:
            self._nodeId = self.collection.tree.selection()[0]
            if self._nodeId.startswith(BOOK_PREFIX):
                self._element = self.collection.books[self._nodeId]
            elif self._nodeId.startswith(SERIES_PREFIX):
                self._element = self.collection.series[self._nodeId]
        except IndexError:
            pass
        except AttributeError:
            pass
        else:
            self._set_element_view()

    def _set_element_view(self, event=None):
        self.indexCard.bodyBox.clear()
        if self._element.desc:
            self.indexCard.bodyBox.set_text(self._element.desc)
        if self._element.title:
            self.indexCard.title.set(self._element.title)

    def _get_element_view(self, event=None):
        try:
            title = self.indexCard.title.get()
            if title or self._element.title:
                if self._element.title != title:
                    self._element.title = title.strip()
                    self.collection.tree.item(self._nodeId, text=self._element.title)
                    self.isModified = True
            if self.indexCard.bodyBox.hasChanged:
                self._element.desc = self.indexCard.bodyBox.get_text()
                self.isModified = True
        except AttributeError:
            pass

    def _show_info(self, message):
        if message.startswith('!'):
            message = message.split('!', maxsplit=1)[1].strip()
            messagebox.showerror(APPLICATION, message=message, parent=self)
        else:
            messagebox.showinfo(APPLICATION, message=message, parent=self)
        self.lift()
        self.focus()

    def _set_info_how(self, message):
        if message.startswith('!'):
            self.statusBar.config(bg='red')
            self.statusBar.config(fg='white')
            self.infoHowText = message.split('!', maxsplit=1)[1].strip()
        else:
            self.statusBar.config(bg='green')
            self.statusBar.config(fg='white')
            self.infoHowText = message
        self.statusBar.config(text=self.infoHowText)

    def _show_path(self, message):
        self._pathText = message
        self.pathBar.config(text=message)

    def _show_status(self, message):
        self._statusText = message
        self.statusBar.config(bg=self.cget('background'))
        self.statusBar.config(fg='black')
        self.statusBar.config(text=message)

    def _restore_status(self, event=None):
        self._show_status(self._statusText)

    def _move_node(self, event):
        tv = event.widget
        node = tv.selection()[0]
        targetNode = tv.identify_row(event.y)
        if node[:2] == targetNode[:2]:
            tv.move(node, tv.parent(targetNode), tv.index(targetNode))
            self.isModified = True
        elif node.startswith(BOOK_PREFIX) and targetNode.startswith(SERIES_PREFIX):
            if not tv.get_children(targetNode):
                tv.move(node, targetNode, 0)
                self.isModified = True
            else:
                tv.move(node, tv.parent(targetNode), tv.index(targetNode))
            self.isModified = True


    def _open_book(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            if nodeId.startswith(BOOK_PREFIX):
                self._ui.open_project(self.collection.books[nodeId].filePath)
        except IndexError:
            pass
        self.focus_set()

    def _add_current_project(self, event=None):
        try:
            selection = self.collection.tree.selection()[0]
        except:
            selection = ''
        parent = ''
        if selection.startswith(BOOK_PREFIX):
            parent = self.collection.tree.parent(selection)
        elif selection.startswith(SERIES_PREFIX):
            parent = selection
        index = self.collection.tree.index(selection) + 1
        book = self._ui.prjFile
        if book is not None:
            try:
                bkId = self.collection.add_book(book, parent, index)
                self.isModified = True
            except Error as ex:
                self._set_info_how(str(ex))
            else:
                if bkId is not None:
                    self._set_info_how(f'"{book.novel.title}" added to the collection.')
                else:
                    self._set_info_how(f'!"{book.novel.title}" already exists.')

    def _update_book(self, event=None):
        novel = self._ui.novel
        if novel is not None:
            for bkId in self.collection.books:
                if novel.title == self.collection.books[bkId].title:
                    if self.collection.books[bkId].pull_metadata(novel):
                        self.isModified = True
                        if self._nodeId == bkId:
                            self._set_element_view()

    def _remove_book(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(BOOK_PREFIX):
                    if messagebox.askyesno(APPLICATION, message=f'{_("Remove selected book from the collection")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_book(nodeId)
                        self.isModified = True
                        self.lift()
                        self.focus()
            except Error as ex:
                self._set_info_how(str(ex))
            else:
                if message:
                    self._set_info_how(message)
        except IndexError:
            pass

    def _add_series(self, event=None):
        try:
            selection = self.collection.tree.selection()[0]
        except:
            selection = ''
        title = 'New Series'
        index = 0
        if selection.startswith(SERIES_PREFIX):
            index = self.collection.tree.index(selection) + 1
        try:
            self.collection.add_series(title, index)
            self.isModified = True
        except Error as ex:
            self._set_info_how(str(ex))

    def _remove_series(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(SERIES_PREFIX):
                    if messagebox.askyesno(APPLICATION, message=f'{_("Remove selected series but keep the books")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_series(nodeId)
                        self.isModified = True
                        self.lift()
                        self.focus()
            except Error as ex:
                self._set_info_how(str(ex))
            else:
                if message:
                    self._set_info_how(message)
        except IndexError:
            pass

    def _remove_series_with_books(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(SERIES_PREFIX):
                    if messagebox.askyesno(APPLICATION, message=f'{_("Remove selected series and books")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_series_with_books(nodeId)
                        self.isModified = True
                        self.lift()
                        self.focus()
            except Error as ex:
                self._set_info_how(str(ex))
            else:
                if message:
                    self._set_info_how(message)
        except IndexError:
            pass

    def _remove_node(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            if nodeId.startswith(SERIES_PREFIX):
                self._remove_series()
            elif nodeId.startswith(BOOK_PREFIX):
                self._remove_book()
            self.isModified = True
        except IndexError:
            pass


    def _select_collection(self, fileName):
        initDir = os.path.dirname(self.kwargs['last_open'])
        if not initDir:
            initDir = './'
        if not fileName or not os.path.isfile(fileName):
            fileName = filedialog.askopenfilename(filetypes=self._fileTypes, defaultextension=self._fileTypes[0][1], initialdir=initDir, parent=self)
        if not fileName:
            return ''

        return fileName

    def _open_collection(self, fileName):
        self._show_status(self._statusText)
        fileName = self._select_collection(fileName)
        self.lift()
        self.focus()
        if not fileName:
            return False

        if self.collection is not None:
            self._close_collection()

        self.kwargs['last_open'] = fileName
        self.collection = Collection(fileName, self.treeView)
        try:
            self.collection.read()
        except Error as ex:
            self._close_collection()
            self._set_info_how(f'!{str(ex)}')
            return False

        self._show_path(f'{norm_path(self.collection.filePath)}')
        self._set_title()
        self.fileMenu.entryconfig(_('Close'), state='normal')
        return True

    def _new_collection(self, event=None):
        fileName = filedialog.asksaveasfilename(filetypes=self._fileTypes, defaultextension=self._fileTypes[0][1])
        self.lift()
        self.focus()
        if not fileName:
            return False

        if self.collection is not None:
            self._close_collection()

        self.collection = Collection(fileName, self.treeView)
        self.kwargs['last_open'] = fileName
        self._show_path(f'{norm_path(self.collection.filePath)}')
        self._set_title()
        self.fileMenu.entryconfig(_('Close'), state='normal')
        return True

    def _close_collection(self, event=None):
        self._get_element_view()
        self.indexCard.title.set('')
        self.indexCard.bodyBox.clear()
        self.collection.reset_tree()
        self.collection = None
        self.title('')
        self._show_status('')
        self._show_path('')
        self.fileMenu.entryconfig(_('Close'), state='disabled')

    def _set_title(self):
        if self.collection.title:
            collectionTitle = self.collection.title
        else:
            collectionTitle = _('Untitled collection')
        self.title(f'{collectionTitle} - {PLUGIN}')


DEFAULT_FILE = 'collection.pwc'


class Plugin:
    """novelyst collection manager plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.    
    """
    VERSION = '5.0.8'
    NOVELYST_API = '0.1'
    DESCRIPTION = 'A book/series collection manager'
    URL = 'https://peter88213.github.io/novelyst_collection'
    _HELP_URL = 'https://peter88213.github.io/novelyst_collection/usage'
    ICON = 'cLogo32'

    def install(self, ui):
        """Add a submenu to the 'File' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._collectionManager = None

        self._ui.fileMenu.insert_command(0, label=APPLICATION, command=self._start_manager)
        self._ui.fileMenu.insert_separator(1)
        self._ui.fileMenu.entryconfig(APPLICATION, state='normal')

        self._ui.helpMenu.add_command(label=_('Collection plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))

        self.sectionEditors = {}
        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self._icon = tk.PhotoImage(file=f'{path}/icons/{self.ICON}.png')
        except:
            self._icon = None

    def _start_manager(self):
        if self._collectionManager:
            if self._collectionManager.isOpen:
                self._collectionManager.lift()
                self._collectionManager.focus()
                return

        __, x, y = self._ui.root.geometry().split('+')
        offset = 300
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.noveltree/config'
        except:
            configDir = '.'
        self._collectionManager = CollectionManager(self._ui, windowGeometry, configDir)
        self._collectionManager.iconphoto(False, self._icon)

    def on_quit(self):
        if self._collectionManager:
            if self._collectionManager.isOpen:
                self._collectionManager.on_quit()
