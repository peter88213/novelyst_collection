"""A project collection manager plugin for novelyst.

Compatibility: novelyst v2.0 API 
Requires Python 3.6+
Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_collection
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from html import unescape

import sys
import gettext
import locale

__all__ = ['Error',
           '_',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           ]


class Error(Exception):
    """Base class for exceptions."""


# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('novelyst_collection', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message



def indent(elem, level=0):
    """xml pretty printer

    Kudos to to Fredrik Lundh. 
    Source: http://effbot.org/zone/element-lib.htm#prettyprint
    """
    i = f'\n{level * "  "}'
    if elem:
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i



class Series:
    """Book series representation for the collection.
    
    A series has a title, a description, and a list of book IDs.
    
    """

    def __init__(self, title, description=''):
        self.title = title
        self.desc = description
        self.srtBooks = []

    def add_book(self, bkId):
        """Add a new book ID to the list. 
        
        Avoid multiple entries.
        Return True on success, 
        return False, if the book is already a member.  
        """
        if (bkId in self.srtBooks):
            return False
        else:
            self.srtBooks.append(bkId)
            return True

    def remove_book(self, bkId):
        """Remove an existing book ID from the list.       

        Return a message.
        Raise the "Error" exception in case of error.
        """
        try:
            self.srtBooks.remove(bkId)
            return 'Book removed from series.'
        except:
            raise Error(f'Cannot remove book from the list.')


class Book:
    """Book representation for the collection.
    
    This is a lightweight placeholder for a Yw7File instance,
    holding only the necessary metadata. 
    """

    def __init__(self, filePath):
        self.filePath = filePath
        self.title = None
        self.desc = None

    def pull_metadata(self, novel):
        """Update metadata from novel."""
        self.title = novel.title
        self.desc = novel.desc

    def push_metadata(self, novel):
        """Update novel metadata.
        
        Return True, if the novel is modified, 
        otherwise return False. 
        """
        modified = False
        if novel.title != self.title:
            novel.title = self.title
            modified = True
        if novel.desc != self.desc:
            novel.desc = self.desc
            modified = True
        return modified



class Collection:
    """Represent a collection of yWriter projects. 
    
    - A collection has books and series.
    - Books can be members of a series.
    
    The collection data is saved in an XML file.
    """
    _FILE_EXTENSION = 'pwc'

    _CDATA_TAGS = ['Title', 'Desc', 'Path']
    # Names of xml elements containing CDATA.
    # ElementTree.write omits CDATA tags, so they have to be inserted afterwards.

    def __init__(self, filePath):
        """Initialize the instance variables.
        
        Positional argument:
            filePath -- str: path to xml file.
        """
        self.books = {}
        # Dictionary:
        #   keyword -- book ID
        #   value -- Book instance

        self.srtSeries = []
        # List of series IDs

        self._filePath = None
        # Location of the collection XML file.

        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        """Accept only filenames with the right extension. """
        if filePath.lower().endswith(self._FILE_EXTENSION):
            self._filePath = filePath

    def read(self):
        """Parse the pwc XML file located at filePath, fetching the Collection attributes.
        
        Return a message.
        Raise the "Error" exception in case of error.
        """

        # Open the file and let ElementTree parse its xml structure.
        try:
            tree = ET.parse(self._filePath)
            root = tree.getroot()
        except:
            raise Error(f'Can not process "{self._filePath}".')

        for series in root.iter('SERIES'):
            newSeries = Series(series.find('Title').text)
            if series.find('Desc') is not None:
                newSeries.desc = series.find('Desc').text
            newSeries.srtBooks = []
            if series.find('Books') is not None:
                for book in series.find('Books').findall('BkID'):
                    bkId = book.text
                    newSeries.srtBooks.append(bkId)
            self.srtSeries.append(newSeries)
        for book in root.iter('BOOK'):
            bkId = book.find('ID').text
            bookPath = book.find('Path').text
            if os.path.isfile(bookPath):
                self.books[bkId] = Book(bookPath)
                if book.find('Title') is not None:
                    self.books[bkId].title = book.find('Title').text
                if book.find('Desc') is not None:
                    self.books[bkId].desc = book.find('Desc').text
        return f'{len(self.books)} Books found in "{self._filePath}".'

    def write(self):
        """Write the collection's attributes to a pwc XML file located at filePath. 
        
        Overwrite existing file without confirmation.
        Return a message.
        Raise the "Error" exception in case of error.
        """
        root = ET.Element('COLLECTION')
        bkSection = ET.SubElement(root, 'BOOKS')
        for bookId in self.books:
            newBook = ET.SubElement(bkSection, 'BOOK')
            bkId = ET.SubElement(newBook, 'ID')
            bkId.text = bookId
            bkPath = ET.SubElement(newBook, 'Path')
            bkPath.text = self.books[bookId].filePath
            bkTitle = ET.SubElement(newBook, 'Title')
            bkTitle.text = self.books[bookId].title
            bkDesc = ET.SubElement(newBook, 'Desc')
            bkDesc.text = self.books[bookId].desc
        srSection = ET.SubElement(root, 'SRT_SERIES')
        for series in self.srtSeries:
            newSeries = ET.SubElement(srSection, 'SERIES')
            serTitle = ET.SubElement(newSeries, 'Title')
            serTitle.text = series.title
            serDesc = ET.SubElement(newSeries, 'Desc')
            serDesc.text = series.desc
            serBooks = ET.SubElement(newSeries, 'Books')
            for bookId in series.srtBooks:
                bkId = ET.SubElement(serBooks, 'BkID')
                bkId.text = bookId
        indent(root)
        tree = ET.ElementTree(root)
        try:
            tree.write(self._filePath, encoding='utf-8')
        except(PermissionError):
            raise Error(f'"{self._filePath}" is write protected.')

        # Postprocess the xml file created by ElementTree
        self._postprocess_xml_file(self.filePath)
        return f'"{os.path.normpath(self.filePath)}" written.'

    def add_book(self, novel):
        """Add an existing yw7 file as book to the collection. 
        
        Return the book ID, if novel is added to the collection.
        Return None, if vovel is already a member.
        Raise the "Error" exception in case of error.
        """
        if os.path.isfile(novel.filePath):
            for bkId in self.books:
                if novel.filePath == self.books[bkId].filePath:
                    return None

            i = 1
            while str(i) in self.books:
                i += 1
            bkId = str(i)
            self.books[bkId] = Book(novel.filePath)
            self.books[bkId].pull_metadata(novel)
            return bkId

        else:
            raise Error(f'"{os.path.normpath(novel.filePath)}" not found.')

    def remove_book(self, bkId):
        """Remove a book from the collection and from the series.

        Return a message.
        Raise the "Error" exception in case of error.
        """
        try:
            bookTitle = self.books[bkId].title
            del self.books[bkId]
            message = f'Book "{bookTitle}" removed from the collection.'
            for series in self.srtSeries:
                try:
                    series.remove_book(bkId)
                except Error:
                    pass
                else:
                    message = f'Book "{bookTitle}" removed from "{series.title}" series.'

            return message
        except:
            raise Error(f'Cannot remove "{bookTitle}".')

    def add_series(self, serTitle):
        """Instantiate a Series object and append it to the srtSeries list.
        
        Avoid multiple entries.
        Return True on success, 
        return False, if the series is already a member.         
        """
        for series in self.srtSeries:
            if series.title == serTitle:
                return False

        newSeries = Series(serTitle)
        self.srtSeries.append(newSeries)
        return True

    def remove_series(self, serTitle):
        """Delete a Series object and remove it from the srtSeries list.
        
        Return a message.
        Raise the "Error" exception in case of error.
        """
        for series in self.srtSeries:
            if series.title == serTitle:
                self.srtSeries.remove(series)
                return f'"{serTitle}" series removed from the collection.'

        raise Error(f'Cannot remove "{serTitle}" series from the collection.')

    def _postprocess_xml_file(self, filePath):
        '''Postprocess an xml file created by ElementTree.
        
        Positional argument:
            filePath -- str: path to xml file.
        
        Read the xml file, put a header on top, insert the missing CDATA tags,
        and replace xml entities by plain text (unescape). Overwrite the .yw7 xml file.
        Raise the "Error" exception in case of error. 
        
        Note: The path is given as an argument rather than using self.filePath. 
        So this routine can be used for yWriter-generated xml files other than .yw7 as well. 
        '''
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        newlines = ['<?xml version="1.0" encoding="utf-8"?>']
        for line in lines:
            for tag in self._CDATA_TAGS:
                line = re.sub(f'\<{tag}\>', f'<{tag}><![CDATA[', line)
                line = re.sub(f'\<\/{tag}\>', f']]></{tag}>', line)
            newlines.append(line)
        text = '\n'.join(newlines)
        text = text.replace('[CDATA[ \n', '[CDATA[')
        text = text.replace('\n]]', ']]')
        text = unescape(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "{os.path.normpath(filePath)}".')

import tkinter as tk
from tkinter import messagebox
from tkinter import ttk


class CollectionManager(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, ui, windowGeometry, collection, **kw):
        self._ui = ui
        super().__init__(**kw)
        self.geometry(windowGeometry)
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        #--- Main menu.
        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        #--- File menu.
        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        # self.fileMenu.add_command(label=_('Open...'), accelerator=self._KEY_OPEN_PROJECT[1], command=lambda: self.open_project(''))
        # self.fileMenu.add_command(label=_('Close'), command=self.close_project)
        # self.fileMenu.entryconfig(_('Close'), state='disabled')
        self.fileMenu.add_command(label=_('Exit'), accelerator=self._KEY_QUIT_PROGRAM[1], command=self.on_quit)

        #--- Series menu.
        self.seriesMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Series'), menu=self.seriesMenu)

        #--- Book menu.
        self.bookMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Book'), menu=self.bookMenu)
        self.bookMenu.add_command(label=_('Update book data from current project'), command=self._update_book)
        self.bookMenu.add_command(label=_('Add current project to collection'), command=self._add_current_project)
        self.bookMenu.add_command(label=_('Remove selected book from collection'), command=self._remove_selected_book)

        #--- Main window.
        self.mainWindow = ttk.Frame(self)
        self.mainWindow.pack(fill=tk.BOTH, padx=2, pady=2)
        self.collection = collection

        #--- Listbox for book selection.
        self.listbox = tk.Listbox(self.mainWindow, selectmode=tk.SINGLE)
        self.listbox.pack(side=tk.LEFT, fill=tk.Y)
        self.listbox.bind('<<ListboxSelect>>', self._show_desc)
        self.listbox.bind('<Double-1>', self._open_project)
        self.listbox.bind('<Return>', self._open_project)

        #--- Viewer window for the description.
        self.viewer = tk.Text(self.mainWindow, wrap='word')
        self.viewer.pack()

        self._build_tree()
        self.isOpen = True

    def _build_tree(self):
        self.listbox.delete(0, tk.END)
        self.booklist = []
        for bkId in self.collection.books:
            self.booklist.append(bkId)
            self.listbox.insert(tk.END, self.collection.books[bkId].title)

    def _show_desc(self, event=None):
        """View the selected book's description."""
        selection = event.widget.curselection()
        if selection:
            index = selection[0]
            self.viewer.delete('1.0', tk.END)
            desc = self.collection.books[self.booklist[index]].desc
            if desc:
                self.viewer.insert(tk.END, desc)

    def _open_project(self, event=None):
        """Make the application open the selected book's project."""
        selection = event.widget.curselection()
        if selection:
            index = selection[0]
            self._ui.open_project(self.collection.books[self.booklist[index]].filePath)

    def _add_current_project(self, event=None):
        novel = self._ui.ywPrj
        if novel is not None:
            try:
                bkId = self.collection.add_book(novel)
            except Error as ex:
                self._show_info(str(ex))
            else:
                if bkId is not None:
                    self.booklist.append(bkId)
                    self.listbox.insert(tk.END, self.collection.books[bkId].title)
                    self._show_info(f'"{novel.title}" added to the collection.')
                else:
                    self._show_info(f'!"{novel.title}" already exists.')

    def _update_book(self, event=None):
        novel = self._ui.ywPrj
        if novel is not None:
            for bkId in self.collection.books:
                if novel.title == self.collection.books[bkId].title:
                    self.collection.books[bkId].pull_metadata(novel)

    def _remove_selected_book(self, event=None):
        selection = self.listbox.curselection()
        if selection:
            index = selection[0]
            bkId = self.booklist.pop(index)
            message = ''
            try:
                message = self.collection.remove_book(bkId)
                self.listbox.delete(index)
            except Error as ex:
                self._show_info(str(ex))
            else:
                if message:
                    self._show_info(message)

    def _show_info(self, message):
        if message.startswith('!'):
            message = message.split('!', maxsplit=1)[1].strip()
            messagebox.showerror(message=message)
        else:
            messagebox.showinfo(message=message)
        self.lift()
        self.focus()

    def on_quit(self, event=None):
        try:
            self.collection.write()
        except Exception as ex:
            self._show_info(str(ex))
        finally:
            self.destroy()
            self.isOpen = False

APPLICATION = 'Collection'
DEFAULT_FILE = 'collection.pwc'


class Plugin:
    """novelyst collection manager plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.    
    """
    VERSION = '2.0.0'
    NOVELYST_API = '2.0'
    DESCRIPTION = 'A book/series collection manager'
    URL = 'https://peter88213.github.io/novelyst_collection'

    def install(self, ui):
        """Add a submenu to the 'File' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._collectionManager = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            installDir = f'{homeDir}/.pywriter/collection'
        except:
            installDir = '.'
        os.makedirs(installDir, exist_ok=True)
        filePath = f'{installDir}/{DEFAULT_FILE}'
        self.collection = Collection(filePath)
        if os.path.isfile(filePath):
            self.collection.read()

        # Create a submenu
        self._ui.fileMenu.insert_command(0, label=APPLICATION, command=self._start_manager)
        self._ui.fileMenu.insert_separator(1)
        self._ui.fileMenu.entryconfig(APPLICATION, state='normal')

    def _start_manager(self):
        __, x, y = self._ui.root.geometry().split('+')
        offset = 300
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        if self._collectionManager:
            if self._collectionManager.isOpen:
                self._collectionManager.lift()
                self._collectionManager.focus()
                return

        self._collectionManager = CollectionManager(self._ui, windowGeometry, self.collection)
