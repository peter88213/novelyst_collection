"""A project collection manager plugin for novelyst.

Requires Python 3.6+
Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_collection
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
from pathlib import Path
import sys
import gettext
import locale

__all__ = ['Error',
           '_',
           'norm_path',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'APPLICATION',
           'PLUGIN',
           ]


class Error(Exception):
    """Base class for exceptions."""


# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('novelyst_collection', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Collection')
PLUGIN = f'{APPLICATION} plugin v4.0.2'


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)

import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk
from tkinter import ttk


class TextBox(tk.Text):
    """A text box with a ttk scrollbar and a change flag.
    """

    def __init__(self, master=None, **kw):
        """Define some tags for novelyst-specific colors.
        
        Copied from tkinter.scrolledtext and modified (use ttk widgets).
        Extends the supeclass constructor.
        """
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side=tk.RIGHT, fill=tk.Y)

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.vbar['command'] = self.yview

        # Copy geometry methods of self.frame without overriding Text
        # methods -- hack!
        text_meths = vars(tk.Text).keys()
        methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        # This part is project-specific:
        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def _on_edit(self, event=None):
        "Event handler to indicate changes."""
        self.hasChanged = True

    def get_text(self):
        return self.get('1.0', tk.END).strip(' \n')

    def set_text(self, text):
        self.clear()
        if text:
            self.insert(tk.END, text)
            self.edit_reset()
            # this is to prevent the user from clearing the box with Ctrl-Z

    def clear(self):
        self.delete('1.0', tk.END)
        self.hasChanged = False

import re
from html import unescape
import xml.etree.ElementTree as ET
import tkinter.font as tkFont



def indent(elem, level=0):
    """xml pretty printer

    Kudos to to Fredrik Lundh. 
    Source: http://effbot.org/zone/element-lib.htm#prettyprint
    """
    i = f'\n{level * "  "}'
    if elem:
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def create_id(elements):
    """Return an unused ID for a new element.
    
    Positional arguments:
        elements -- list or dictionary containing all existing IDs
    """
    i = 1
    while str(i) in elements:
        i += 1
    return str(i)




class Series:
    """Book series representation for the collection.
    
    A series has a title and a description. 
    """

    def __init__(self):
        self.title = None
        self.desc = None


class Book:
    """Book representation for the collection.
    
    This is a lightweight placeholder for a Yw7File instance,
    holding only the necessary metadata. 
    """

    def __init__(self, filePath):
        self.filePath = filePath
        self.title = None
        self.desc = None

    def pull_metadata(self, novel):
        """Update metadata from novel.

        Return True, if the novel is modified, 
        otherwise return False. 
        """
        modified = False
        if self.title != novel.title:
            self.title = novel.title
            modified = True
        if self.desc != novel.desc:
            self.desc = novel.desc
            modified = True
        return modified

    def push_metadata(self, novel):
        """Update novel metadata.
        
        Return True, if the novel is modified, 
        otherwise return False. 
        """
        modified = False
        if novel.title != self.title:
            novel.title = self.title
        if novel.desc != self.desc:
            novel.desc = self.desc
            modified = True
        return modified



class Collection:
    """Represent a collection of yWriter projects. 
    
    - A collection has books and series.
    - Books can be members of a series.
    
    The collection data is saved in an XML file.
    """
    _FILE_EXTENSION = 'pwc'
    _SERIES_PREFIX = 'sr'
    _BOOK_PREFIX = 'bk'

    _CDATA_TAGS = ['Title', 'Desc', 'Path']
    # Names of xml books containing CDATA.
    # ElementTree.write omits CDATA tags, so they have to be inserted afterwards.

    def __init__(self, filePath, tree):
        """Initialize the instance variables.
        
        Positional arguments:
            filePath -- str: path to xml file.
            tree -- tree structure of series and book IDs.
        """
        self.title = None
        self.tree = tree
        fontSize = tkFont.nametofont('TkDefaultFont').actual()['size']
        self.tree.tag_configure('series', font=('', fontSize, 'bold'))

        self.books = {}
        # Dictionary:
        #   keyword -- book ID
        #   value -- Book instance

        self.series = {}
        # Dictionary:
        #   keyword -- series ID
        #   value -- Series instance

        self._filePath = None
        # Location of the collection XML file.

        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        """Accept only filenames with the right extension. """
        if filePath.lower().endswith(self._FILE_EXTENSION):
            self._filePath = filePath
            self.title, __ = os.path.splitext(os.path.basename(self.filePath))

    def read(self):
        """Parse the pwc XML file located at filePath, fetching the Collection attributes.
        
        Return a message.
        Raise the "Error" exception in case of error.
        """

        def get_book(parent, xmlBook):
            try:
                bkId = xmlBook.attrib['ID']
                item = f'{self._BOOK_PREFIX}{bkId}'
                bookPath = xmlBook.find('Path').text
                if os.path.isfile(bookPath):
                    self.books[bkId] = Book(bookPath)
                    if xmlBook.find('Title') is not None:
                        self.books[bkId].title = xmlBook.find('Title').text
                    else:
                        self.books[bkId].title = item
                    if xmlBook.find('Desc') is not None:
                        self.books[bkId].desc = xmlBook.find('Desc').text
            except:
                pass
            else:
                self.tree.insert(parent, 'end', item, text=self.books[bkId].title, open=True)

        # Open the file and let ElementTree parse its xml structure.
        try:
            xmlTree = ET.parse(self.filePath)
            xmlRoot = xmlTree.getroot()
        except:
            raise Error(f'Can not process "{self.filePath}".')

        self.reset_tree()
        self.books = {}
        self.series = {}
        for xmlElement in xmlRoot:
            if xmlElement.tag == 'BOOK':
                get_book('', xmlElement)
            elif xmlElement.tag == 'SERIES':
                srId = xmlElement.attrib['ID']
                item = f'{self._SERIES_PREFIX}{srId}'
                self.series[srId] = Series()
                if xmlElement.find('Title') is not None:
                    self.series[srId].title = xmlElement.find('Title').text
                else:
                    self.series[srId].title = item
                if xmlElement.find('Desc') is not None:
                    self.series[srId].desc = xmlElement.find('Desc').text
                self.tree.insert('', 'end', item, text=self.series[srId].title, tags='series', open=True)
                for xmlBook in xmlElement.iter('BOOK'):
                    get_book(item, xmlBook)

        return f'{len(self.books)} Books found in "{self.filePath}".'

    def write(self):
        """Write the collection's attributes to a pwc XML file located at filePath. 
        
        Overwrite existing file without confirmation.
        Return a message.
        Raise the "Error" exception in case of error.
        """

        def walk_tree(node, xmlNode):
            """Transform the Treeview nodes to XML Elementtree nodes."""
            for childNode in self.tree.get_children(node):
                elementId = childNode[2:]
                if childNode.startswith(self._BOOK_PREFIX):
                    xmlBook = ET.SubElement(xmlNode, 'BOOK')
                    xmlBook.set('ID', elementId)
                    xmlBookPath = ET.SubElement(xmlBook, 'Path')
                    xmlBookPath.text = self.books[elementId].filePath
                    xmlBookTitle = ET.SubElement(xmlBook, 'Title')
                    if self.books[elementId].title:
                        xmlBookTitle.text = self.books[elementId].title
                    xmlBookDesc = ET.SubElement(xmlBook, 'Desc')
                    if self.books[elementId].desc:
                        xmlBookDesc.text = self.books[elementId].desc
                elif childNode.startswith(self._SERIES_PREFIX):
                    xmlSeries = ET.SubElement(xmlNode, 'SERIES')
                    xmlSeries.set('ID', elementId)
                    xmlSeriesTitle = ET.SubElement(xmlSeries, 'Title')
                    if self.series[elementId].title:
                        xmlSeriesTitle.text = self.series[elementId].title
                    xmlSeriesDesc = ET.SubElement(xmlSeries, 'Desc')
                    if self.series[elementId].desc:
                        xmlSeriesDesc.text = self.series[elementId].desc

                    walk_tree(childNode, xmlSeries)

        xmlRoot = ET.Element('COLLECTION')
        walk_tree('', xmlRoot)

        indent(xmlRoot)
        xmlTree = ET.ElementTree(xmlRoot)
        try:
            xmlTree.write(self.filePath, encoding='utf-8')
        except(PermissionError):
            raise Error(f'"{self.filePath}" is write protected.')

        # Postprocess the xml file created by ElementTree
        self._postprocess_xml_file(self.filePath)
        return f'"{norm_path(self.filePath)}" written.'

    def add_book(self, book, parent='', index='end'):
        """Add an existing project file as book to the collection. 
        
        Return the book ID, if book is added to the collection.
        Return None, if vovel is already a member.
        Raise the "Error" exception in case of error.
        """
        if os.path.isfile(book.filePath):
            for bkId in self.books:
                if book.filePath == self.books[bkId].filePath:
                    return None

            bkId = create_id(self.books)
            self.books[bkId] = Book(book.filePath)
            self.books[bkId].pull_metadata(book.novel)
            self.tree.insert(parent, index, f'{self._BOOK_PREFIX}{bkId}', text=self.books[bkId].title, open=True)
            return bkId

        else:
            raise Error(f'"{norm_path(book.filePath)}" not found.')

    def remove_book(self, nodeId):
        """Remove a book from the collection.

        Return a message.
        Raise the "Error" exception in case of error.
        """
        bkId = nodeId[2:]
        bookTitle = nodeId
        try:
            bookTitle = self.books[bkId].title
            del self.books[bkId]
            self.tree.delete(nodeId)
            message = f'Book "{bookTitle}" removed from the collection.'
            return message
        except:
            raise Error(f'Cannot remove "{bookTitle}".')

    def add_series(self, seriesTitle, index='end'):
        """Instantiate a Series object.
        """
        srId = create_id(self.series)
        self.series[srId] = Series()
        self.series[srId].title = seriesTitle
        self.tree.insert('', index, f'{self._SERIES_PREFIX}{srId}', text=self.series[srId].title, tags='series', open=True)

    def remove_series(self, nodeId):
        """Delete a Series object but keep the books.
        
        Return a message.
        Raise the "Error" exception in case of error.
        """
        srId = nodeId[2:]
        seriesTitle = self.series[srId].title
        for bookNode in self.tree.get_children(nodeId):
            self.tree.move(bookNode, '', 'end')
        del(self.series[srId])
        self.tree.delete(nodeId)
        return f'"{seriesTitle}" series removed from the collection.'

        raise Error(f'Cannot remove "{seriesTitle}" series from the collection.')

    def remove_series_with_books(self, nodeId):
        """Delete a Series object with all its members.
        
        Return a message.
        Raise the "Error" exception in case of error.
        """
        srId = nodeId[2:]
        seriesTitle = self.series[srId].title
        for bookNode in self.tree.get_children(nodeId):
            bkId = bookNode[2:]
            del self.books[bkId]
        del(self.series[srId])
        self.tree.delete(nodeId)
        return f'"{seriesTitle}" series removed from the collection.'

        raise Error(f'Cannot remove "{seriesTitle}" series from the collection.')

    def _postprocess_xml_file(self, filePath):
        '''Postprocess an xml file created by ElementTree.
        
        Positional argument:
            filePath -- str: path to xml file.
        
        Read the xml file, put a header on top, insert the missing CDATA tags,
        and replace xml entities by plain text (unescape). Overwrite the .yw7 xml file.
        Raise the "Error" exception in case of error. 
        
        Note: The path is given as an argument rather than using self.filePath. 
        So this routine can be used for yWriter-generated xml files other than .yw7 as well. 
        '''
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        newlines = ['<?xml version="1.0" encoding="utf-8"?>']
        for line in lines:
            for tag in self._CDATA_TAGS:
                line = re.sub(f'\<{tag}\>', f'<{tag}><![CDATA[', line)
                line = re.sub(f'\<\/{tag}\>', f']]></{tag}>', line)
            newlines.append(line)
        text = '\n'.join(newlines)
        text = text.replace('[CDATA[ \n', '[CDATA[')
        text = text.replace('\n]]', ']]')
        text = unescape(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

    def reset_tree(self):
        """Clear the displayed tree."""
        for child in self.tree.get_children(''):
            self.tree.delete(child)

from configparser import ConfigParser


class Configuration:
    """Application configuration, representing an INI file.

        INI file sections:
        <self._sLabel> - Strings
        <self._oLabel> - Boolean values

    Public methods:
        set(settings={}, options={}) -- set the entire configuration without writing the INI file.
        read(iniFile) -- read a configuration file.
        write(iniFile) -- save the configuration to iniFile.

    Public instance variables:    
        settings - dictionary of strings
        options - dictionary of boolean values
    """

    def __init__(self, settings={}, options={}):
        """Initalize attribute variables.

        Optional arguments:
            settings -- default settings (dictionary of strings)
            options -- default options (dictionary of boolean values)
        """
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def set(self, settings=None, options=None):
        """Set the entire configuration without writing the INI file.

        Optional arguments:
            settings -- new settings (dictionary of strings)
            options -- new options (dictionary of boolean values)
        """
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def read(self, iniFile):
        """Read a configuration file.
        
        Positional arguments:
            iniFile -- str: path configuration file path.
            
        Settings and options that can not be read in, remain unchanged.
        """
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, iniFile):
        """Save the configuration to iniFile.

        Positional arguments:
            iniFile -- str: path configuration file path.
        """
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)

SETTINGS = dict(
    last_open='',
    tree_width='300',
)
OPTIONS = {}


class CollectionManager(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')
    _SERIES_PREFIX = 'sr'
    _BOOK_PREFIX = 'bk'

    def __init__(self, ui, position, configDir):
        self._ui = ui
        super().__init__()

        #--- Load configuration.
        self.iniFile = f'{configDir}/collection.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        # Read the file path from the configuration file.

        self.title(PLUGIN)
        self._statusText = ''

        self.geometry(position)
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        #--- Main menu.
        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        #--- Main window.
        self.mainWindow = ttk.Frame(self)
        self.mainWindow.pack(fill=tk.BOTH, padx=2, pady=2)

        #--- Paned window displaying the tree and an "index card".
        self.treeWindow = ttk.Panedwindow(self.mainWindow, orient=tk.HORIZONTAL)
        self.treeWindow.pack(fill=tk.BOTH, expand=True)

        #--- The collection itself.
        self.collection = None
        self._fileTypes = [(_('novelyst collection'), '.pwc')]

        #--- Tree for book selection.
        self.treeView = ttk.Treeview(self.treeWindow, selectmode='browse')
        self.treeView.pack(side=tk.LEFT)
        self.treeWindow.add(self.treeView)
        self.treeView.bind('<<TreeviewSelect>>', self._on_select_node)
        self.treeView.bind('<<TreeviewSelect>>', self._on_select_node)
        self.treeView.bind('<Double-1>', self._open_book)
        self.treeView.bind('<Return>', self._open_book)
        self.treeView.bind('<Delete>', self._remove_node)
        self.treeView.bind('<Shift-Delete>', self._remove_series_with_books)
        self.treeView.bind('<Alt-B1-Motion>', self._move_node)

        #--- "Index card" in the right frame.
        self.indexCard = tk.Frame(self.treeWindow, bd=2, relief=tk.RIDGE)
        self.indexCard.pack(side=tk.RIGHT)
        self.treeWindow.add(self.indexCard)

        # Title label.
        self.elementTitle = tk.StringVar(value='')
        titleEntry = tk.Entry(self.indexCard, bd=0, textvariable=self.elementTitle, relief=tk.FLAT)
        titleEntry.config({'background': self._ui.kwargs['color_text_bg'],
                           'foreground': self._ui.kwargs['color_text_fg'],
                           'insertbackground': self._ui.kwargs['color_text_fg'],
                           })
        titleEntry.pack(fill=tk.X, ipady=6)

        tk.Frame(self.indexCard, bg='red', height=1, bd=0).pack(fill=tk.X)
        tk.Frame(self.indexCard, bg='white', height=1, bd=0).pack(fill=tk.X)

        # Description window.
        self._viewer = TextBox(self.indexCard,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                padx=5,
                pady=5,
                bg=self._ui.kwargs['color_text_bg'],
                fg=self._ui.kwargs['color_text_fg'],
                insertbackground=self._ui.kwargs['color_text_fg'],
                )
        self._viewer.pack(fill=tk.X)

        # Adjust the tree width.
        self.treeWindow.update()
        self.treeWindow.sashpos(0, self.kwargs['tree_width'])

        # Status bar.
        self.statusBar = tk.Label(self, text='', anchor='w', padx=5, pady=2)
        self.statusBar.pack(expand=False, fill='both')

        # Path bar.
        self.pathBar = tk.Label(self, text='', anchor='w', padx=5, pady=3)
        self.pathBar.pack(expand=False, fill='both')

        #--- Add menu entries.
        # File menu.
        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        self.fileMenu.add_command(label=_('New'), command=self.new_collection)
        self.fileMenu.add_command(label=_('Open...'), command=lambda: self.open_collection(''))
        self.fileMenu.add_command(label=_('Close'), command=self.close_collection)
        self.fileMenu.entryconfig(_('Close'), state='disabled')
        self.fileMenu.add_command(label=_('Exit'), accelerator=self._KEY_QUIT_PROGRAM[1], command=self.on_quit)

        # Series menu.
        self.seriesMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Series'), menu=self.seriesMenu)
        self.seriesMenu.add_command(label=_('Add'), command=self._add_series)
        self.seriesMenu.add_command(label=_('Remove selected series but keep the books'), command=self._remove_series)
        self.seriesMenu.add_command(label=_('Remove selected series and books'), command=self._remove_series_with_books)

        # Book menu.
        self.bookMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Book'), menu=self.bookMenu)
        self.bookMenu.add_command(label=_('Add current project to the collection'), command=self._add_current_project)
        self.bookMenu.add_command(label=_('Remove selected book from the collection'), command=self._remove_book)
        self.bookMenu.add_command(label=_('Update book data from the current project'), command=self._update_book)

        #--- Event bindings.
        self.bind('<Escape>', self.restore_status)

        self._element = None
        self._nodeId = None
        if self.open_collection(self.kwargs['last_open']):
            self.isOpen = True

    #--- Application related methods.

    def _on_select_node(self, event=None):
        self._get_element_view()
        try:
            self._nodeId = self.collection.tree.selection()[0]
            elemId = self._nodeId[2:]
            if self._nodeId.startswith(self._BOOK_PREFIX):
                self._element = self.collection.books[elemId]
            elif self._nodeId.startswith(self._SERIES_PREFIX):
                self._element = self.collection.series[elemId]
        except IndexError:
            pass
        except AttributeError:
            pass
        else:
            self._set_element_view()

    def _set_element_view(self, event=None):
        """View the selected element's title and description."""
        self._viewer.clear()
        if self._element.desc:
            self._viewer.set_text(self._element.desc)
        if self._element.title:
            self.elementTitle.set(self._element.title)

    def _get_element_view(self, event=None):
        """Apply changes."""
        try:
            title = self.elementTitle.get()
            if title or self._element.title:
                if self._element.title != title:
                    self._element.title = title.strip()
                    self.collection.tree.item(self._nodeId, text=self._element.title)
            if self._viewer.hasChanged:
                self._element.desc = self._viewer.get_text()
        except AttributeError:
            pass

    def _show_info(self, message):
        if message.startswith('!'):
            message = message.split('!', maxsplit=1)[1].strip()
            messagebox.showerror(APPLICATION, message=message, parent=self)
        else:
            messagebox.showinfo(APPLICATION, message=message, parent=self)
        self.lift()
        self.focus()

    def on_quit(self, event=None):
        self._get_element_view()
        self.kwargs['tree_width'] = self.treeWindow.sashpos(0)

        #--- Save project specific configuration
        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)
        try:
            if self.collection is not None:
                self.collection.write()
        except Exception as ex:
            self._show_info(str(ex))
        finally:
            self.destroy()
            self.isOpen = False

    def set_info_how(self, message):
        """Show how the converter is doing.
        
        Positional arguments:
            message -- message to be displayed. 
            
        Display the message at the status bar.
        Overrides the superclass method.
        """
        if message.startswith('!'):
            self.statusBar.config(bg='red')
            self.statusBar.config(fg='white')
            self.infoHowText = message.split('!', maxsplit=1)[1].strip()
        else:
            self.statusBar.config(bg='green')
            self.statusBar.config(fg='white')
            self.infoHowText = message
        self.statusBar.config(text=self.infoHowText)

    def show_path(self, message):
        """Put text on the path bar."""
        self._pathText = message
        self.pathBar.config(text=message)

    def show_status(self, message):
        """Put text on the status bar."""
        self._statusText = message
        self.statusBar.config(bg=self.cget('background'))
        self.statusBar.config(fg='black')
        self.statusBar.config(text=message)

    def restore_status(self, event=None):
        """Overwrite error message with the status before."""
        self.show_status(self._statusText)

    def _move_node(self, event):
        """Move a selected node in the collection tree."""
        tv = event.widget
        node = tv.selection()[0]
        targetNode = tv.identify_row(event.y)

        if node[:2] == targetNode[:2]:
            tv.move(node, tv.parent(targetNode), tv.index(targetNode))
        elif node.startswith(self._BOOK_PREFIX) and targetNode.startswith(self._SERIES_PREFIX) and not tv.get_children(targetNode):
            tv.move(node, targetNode, 0)

    #--- Project related methods.

    def _open_book(self, event=None):
        """Make the application open the selected book's project."""
        try:
            nodeId = self.collection.tree.selection()[0]
            if nodeId.startswith(self._BOOK_PREFIX):
                bkId = nodeId[2:]
                self._ui.open_project(self.collection.books[bkId].filePath)
        except IndexError:
            pass

    def _add_current_project(self, event=None):
        try:
            selection = self.collection.tree.selection()[0]
        except:
            selection = ''
        parent = ''
        if selection.startswith(self._BOOK_PREFIX):
            parent = self.collection.tree.parent(selection)
        elif selection.startswith(self._SERIES_PREFIX):
            parent = selection
        index = self.collection.tree.index(selection) + 1
        book = self._ui.prjFile
        if book is not None:
            try:
                bkId = self.collection.add_book(book, parent, index)
            except Error as ex:
                self.set_info_how(str(ex))
            else:
                if bkId is not None:
                    self.set_info_how(f'"{book.novel.title}" added to the collection.')
                else:
                    self.set_info_how(f'!"{book.novel.title}" already exists.')

    def _update_book(self, event=None):
        novel = self._ui.novel
        if novel is not None:
            for bkId in self.collection.books:
                if novel.title == self.collection.books[bkId].title:
                    if self.collection.books[bkId].pull_metadata(novel):
                        if self._nodeId == f'{self._BOOK_PREFIX}{bkId}':
                            self._set_element_view()

    def _remove_book(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(self._BOOK_PREFIX):
                    if messagebox.askyesno(APPLICATION, message=f'{_("Remove selected book from the collection")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_book(nodeId)
            except Error as ex:
                self.set_info_how(str(ex))
            else:
                if message:
                    self.set_info_how(message)
        except IndexError:
            pass

    def _add_series(self, event=None):
        try:
            selection = self.collection.tree.selection()[0]
        except:
            selection = ''
        title = 'New Series'
        index = 0
        if selection.startswith(self._SERIES_PREFIX):
            index = self.collection.tree.index(selection) + 1
        try:
            self.collection.add_series(title, index)
        except Error as ex:
            self.set_info_how(str(ex))

    def _remove_series(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(self._SERIES_PREFIX):
                    if messagebox.askyesno(APPLICATION, message=f'{_("Remove selected series but keep the books")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_series(nodeId)
            except Error as ex:
                self.set_info_how(str(ex))
            else:
                if message:
                    self.set_info_how(message)
        except IndexError:
            pass

    def _remove_series_with_books(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(self._SERIES_PREFIX):
                    if messagebox.askyesno(APPLICATION, message=f'{_("Remove selected series and books")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_series_with_books(nodeId)
            except Error as ex:
                self.set_info_how(str(ex))
            else:
                if message:
                    self.set_info_how(message)
        except IndexError:
            pass

    def _remove_node(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            if nodeId.startswith(self._SERIES_PREFIX):
                self._remove_series()
            elif nodeId.startswith(self._BOOK_PREFIX):
                self._remove_book()
        except IndexError:
            pass

    #--- Collection related methods.

    def select_collection(self, fileName):
        """Return a collection file path.

        Positional arguments:
            fileName -- str: collection file path.
            
        Optional arguments:
            fileTypes -- list of tuples for file selection (display text, extension).

        Priority:
        1. use file name argument
        2. open file select dialog

        On error, return an empty string.
        """
        initDir = os.path.dirname(self.kwargs['last_open'])
        if not initDir:
            initDir = './'
        if not fileName or not os.path.isfile(fileName):
            fileName = filedialog.askopenfilename(filetypes=self._fileTypes, defaultextension=self._fileTypes[0][1], initialdir=initDir)
        if not fileName:
            return ''

        return fileName

    def open_collection(self, fileName):
        """Create a Collection instance and read the file.

        Positional arguments:
            fileName -- str: collection file path.
            
        Display collection title and file path.
        Return True on success, otherwise return False.
        """
        self.show_status(self._statusText)
        fileName = self.select_collection(fileName)
        self.lift()
        self.focus()
        if not fileName:
            return False

        if self.collection is not None:
            self.close_collection()

        self.kwargs['last_open'] = fileName
        self.collection = Collection(fileName, self.treeView)
        try:
            self.collection.read()
        except Error as ex:
            self.close_collection()
            self.set_info_how(f'!{str(ex)}')
            return False

        self.show_path(f'{norm_path(self.collection.filePath)}')
        self.set_title()
        self.fileMenu.entryconfig(_('Close'), state='normal')
        return True

    def new_collection(self, event=None):
        """Create a collection.

        Display collection title and file path.
        Return True on success, otherwise return False.
        """
        fileName = filedialog.asksaveasfilename(filetypes=self._fileTypes, defaultextension=self._fileTypes[0][1])
        self.lift()
        self.focus()
        if not fileName:
            return False

        if self.collection is not None:
            self.close_collection()

        self.collection = Collection(fileName, self.treeView)
        self.kwargs['last_open'] = fileName
        self.show_path(f'{norm_path(self.collection.filePath)}')
        self.set_title()
        self.fileMenu.entryconfig(_('Close'), state='normal')
        return True

    def close_collection(self, event=None):
        """Close the collection without saving and reset the user interface.
        
        To be extended by subclasses.
        """
        self._get_element_view()
        self.elementTitle.set('')
        self._viewer.clear()
        self.collection.reset_tree()
        self.collection = None
        self.title('')
        self.show_status('')
        self.show_path('')
        self.fileMenu.entryconfig(_('Close'), state='disabled')

    def set_title(self):
        """Set the main window title. 
        
        'Collection title - application'
        """
        if self.collection.title:
            collectionTitle = self.collection.title
        else:
            collectionTitle = _('Untitled collection')
        self.title(f'{collectionTitle} - {PLUGIN}')


DEFAULT_FILE = 'collection.pwc'


class Plugin:
    """novelyst collection manager plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.    
    """
    VERSION = '4.0.2'
    NOVELYST_API = '4.0'
    DESCRIPTION = 'A book/series collection manager'
    URL = 'https://peter88213.github.io/novelyst_collection'

    def install(self, ui):
        """Add a submenu to the 'File' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._collectionManager = None

        # Create a submenu
        self._ui.fileMenu.insert_command(0, label=APPLICATION, command=self._start_manager)
        self._ui.fileMenu.insert_separator(1)
        self._ui.fileMenu.entryconfig(APPLICATION, state='normal')

    def _start_manager(self):
        if self._collectionManager:
            if self._collectionManager.isOpen:
                self._collectionManager.lift()
                self._collectionManager.focus()
                return

        __, x, y = self._ui.root.geometry().split('+')
        offset = 300
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.pywriter/novelyst/config'
        except:
            configDir = '.'
        self._collectionManager = CollectionManager(self._ui, windowGeometry, configDir)

    def on_quit(self):
        """Write back the configuration file."""
        if self._collectionManager:
            if self._collectionManager.isOpen:
                self._collectionManager.on_quit()
