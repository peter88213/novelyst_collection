"""A project collection manager plugin for novelyst.

Compatibility: novelyst v2.0 API 
Requires Python 3.6+
Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_collection
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
from pathlib import Path
import re
import sys
import gettext
import locale

__all__ = ['Error',
           '_',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           ]


class Error(Exception):
    """Base class for exceptions."""


# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('novelyst_collection', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

import xml.etree.ElementTree as ET
from html import unescape



def indent(elem, level=0):
    """xml pretty printer

    Kudos to to Fredrik Lundh. 
    Source: http://effbot.org/zone/element-lib.htm#prettyprint
    """
    i = f'\n{level * "  "}'
    if elem:
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def create_id(elements):
    """Return an unused ID for a new element.
    
    Positional arguments:
        elements -- list or dictionary containing all existing IDs
    """
    i = 1
    while str(i) in elements:
        i += 1
    return str(i)




class Series:
    """Book series representation for the collection.
    
    A series has a title, a description, and a list of book IDs. 
    """

    def __init__(self):
        self.title = None
        self.desc = None
        self.srtBooks = []

    def add_book(self, bkId):
        """Add a new book ID to the list. 
        
        Avoid multiple entries.
        Return True on success, 
        return False, if the book is already a member.  
        """
        if (bkId in self.srtBooks):
            return False
        else:
            self.srtBooks.append(bkId)
            return True

    def remove_book(self, bkId):
        """Remove an existing book ID from the list.       

        Return a message.
        Raise the "Error" exception in case of error.
        """
        try:
            self.srtBooks.remove(bkId)
            return 'Book removed from series.'
        except:
            raise Error(f'Cannot remove book from the list.')


class Book:
    """Book representation for the collection.
    
    This is a lightweight placeholder for a Yw7File instance,
    holding only the necessary metadata. 
    """

    def __init__(self, filePath):
        self.filePath = filePath
        self.title = None
        self.desc = None

    def pull_metadata(self, novel):
        """Update metadata from novel."""
        self.title = novel.title
        self.desc = novel.desc

    def push_metadata(self, novel):
        """Update novel metadata.
        
        Return True, if the novel is modified, 
        otherwise return False. 
        """
        modified = False
        if novel.title != self.title:
            novel.title = self.title
            modified = True
        if novel.desc != self.desc:
            novel.desc = self.desc
            modified = True
        return modified



class Collection:
    """Represent a collection of yWriter projects. 
    
    - A collection has books and series.
    - Books can be members of a series.
    
    The collection data is saved in an XML file.
    """
    _FILE_EXTENSION = 'pwc'

    _CDATA_TAGS = ['Title', 'Desc', 'Path']
    # Names of xml books containing CDATA.
    # ElementTree.write omits CDATA tags, so they have to be inserted afterwards.

    def __init__(self, filePath):
        """Initialize the instance variables.
        
        Positional argument:
            filePath -- str: path to xml file.
        """
        self.books = {}
        # Dictionary:
        #   keyword -- book ID
        #   value -- Book instance

        self.series = {}
        # Dictionary:
        #   keyword -- book ID
        #   value -- Series instance

        self.srtSeries = []
        # List of series IDs

        self._filePath = None
        # Location of the collection XML file.

        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        """Accept only filenames with the right extension. """
        if filePath.lower().endswith(self._FILE_EXTENSION):
            self._filePath = filePath

    def read(self):
        """Parse the pwc XML file located at filePath, fetching the Collection attributes.
        
        Return a message.
        Raise the "Error" exception in case of error.
        """

        # Open the file and let ElementTree parse its xml structure.
        try:
            xmlTree = ET.parse(self._filePath)
            xmlRoot = xmlTree.getroot()
        except:
            raise Error(f'Can not process "{self._filePath}".')

        self.series = {}
        self.srtSeries = []
        seriesCount = 0
        for xmlSeries in xmlRoot.iter('SERIES'):
            seriesCount += 1
            srId = str(seriesCount)
            self.srtSeries.append(srId)
            self.series[srId] = Series()
            if xmlSeries.find('Title') is not None:
                self.series[srId].title = xmlSeries.find('Title').text
            if xmlSeries.find('Desc') is not None:
                self.series[srId].desc = xmlSeries.find('Desc').text

            self.series[srId].srtBooks = []
            if xmlSeries.find('Books') is not None:
                for xmlBookId in xmlSeries.find('Books').findall('BkID'):
                    bkId = xmlBookId.text
                    self.series[srId].srtBooks.append(bkId)

        for xmlBook in xmlRoot.iter('BOOK'):
            bkId = xmlBook.find('ID').text
            bookPath = xmlBook.find('Path').text
            if os.path.isfile(bookPath):
                self.books[bkId] = Book(bookPath)
                if xmlBook.find('Title') is not None:
                    self.books[bkId].title = xmlBook.find('Title').text
                if xmlBook.find('Desc') is not None:
                    self.books[bkId].desc = xmlBook.find('Desc').text
        return f'{len(self.books)} Books found in "{self._filePath}".'

    def write(self):
        """Write the collection's attributes to a pwc XML file located at filePath. 
        
        Overwrite existing file without confirmation.
        Return a message.
        Raise the "Error" exception in case of error.
        """
        xmlRoot = ET.Element('COLLECTION')

        xmlBookSection = ET.SubElement(xmlRoot, 'BOOKS')
        for bkId in self.books:
            xmlBook = ET.SubElement(xmlBookSection, 'BOOK')
            xmlBookId = ET.SubElement(xmlBook, 'ID')
            xmlBookId.text = bkId
            xmlBookPath = ET.SubElement(xmlBook, 'Path')
            xmlBookPath.text = self.books[bkId].filePath
            xmlBookTitle = ET.SubElement(xmlBook, 'Title')
            if self.books[bkId].title:
                xmlBookTitle.text = self.books[bkId].title
            xmlBookDesc = ET.SubElement(xmlBook, 'Desc')
            if self.books[bkId].desc:
                xmlBookDesc.text = self.books[bkId].desc

        xmlSeriesSection = ET.SubElement(xmlRoot, 'SRT_SERIES')
        for srId in self.srtSeries:
            xmlSeries = ET.SubElement(xmlSeriesSection, 'SERIES')
            xmlSeriesTitle = ET.SubElement(xmlSeries, 'Title')
            if self.series[srId].title:
                xmlSeriesTitle.text = self.series[srId].title
            xmlSeriesDesc = ET.SubElement(xmlSeries, 'Desc')
            if self.series[srId].desc:
                xmlSeriesDesc.text = self.series[srId].desc
            xmlSeriesBooks = ET.SubElement(xmlSeries, 'Books')
            for bkId in self.series[srId].srtBooks:
                xmlBookId = ET.SubElement(xmlSeriesBooks, 'BkID')
                xmlBookId.text = bkId
        indent(xmlRoot)
        xmlTree = ET.ElementTree(xmlRoot)
        try:
            xmlTree.write(self._filePath, encoding='utf-8')
        except(PermissionError):
            raise Error(f'"{self._filePath}" is write protected.')

        # Postprocess the xml file created by ElementTree
        self._postprocess_xml_file(self.filePath)
        return f'"{os.path.normpath(self.filePath)}" written.'

    def add_book(self, novel):
        """Add an existing yw7 file as book to the collection. 
        
        Return the book ID, if novel is added to the collection.
        Return None, if vovel is already a member.
        Raise the "Error" exception in case of error.
        """
        if os.path.isfile(novel.filePath):
            for bkId in self.books:
                if novel.filePath == self.books[bkId].filePath:
                    return None

            i = 1
            while str(i) in self.books:
                i += 1
            bkId = str(i)
            self.books[bkId] = Book(novel.filePath)
            self.books[bkId].pull_metadata(novel)
            return bkId

        else:
            raise Error(f'"{os.path.normpath(novel.filePath)}" not found.')

    def remove_book(self, bkId):
        """Remove a book from the collection and from the series.

        Return a message.
        Raise the "Error" exception in case of error.
        """
        bookTitle = bkId
        try:
            bookTitle = self.books[bkId].title
            del self.books[bkId]
            message = f'Book "{bookTitle}" removed from the collection.'
            for srId in self.srtSeries:
                try:
                    self.series[srId].remove_book(bkId)
                except Error:
                    pass
                else:
                    message = f'Book "{bookTitle}" removed from "{self.series[srId].title}" series.'

            return message
        except:
            raise Error(f'Cannot remove "{bookTitle}".')

    def add_series(self, seriesTitle):
        """Instantiate a Series object and append it to the srtSeries list.
        
        Avoid multiple entries.
        Return True on success, 
        return False, if the series is already a member.         
        """
        for srId in self.series:
            if self.series[srId].title == seriesTitle:
                return False

        srId = create_id(self.series)
        self.series[srId] = Series()
        self.series[srId].title = seriesTitle
        self.srtSeries.append(srId)
        return True

    def remove_series(self, seriesTitle):
        """Delete a Series object and remove it from the srtSeries list.
        
        Return a message.
        Raise the "Error" exception in case of error.
        """
        for srId in self.srtSeries:
            if self.series[srId].title == seriesTitle:
                self.srtSeries.remove(srId)
                del(self.series[srId])
                return f'"{seriesTitle}" series removed from the collection.'

        raise Error(f'Cannot remove "{seriesTitle}" series from the collection.')

    def _postprocess_xml_file(self, filePath):
        '''Postprocess an xml file created by ElementTree.
        
        Positional argument:
            filePath -- str: path to xml file.
        
        Read the xml file, put a header on top, insert the missing CDATA tags,
        and replace xml entities by plain text (unescape). Overwrite the .yw7 xml file.
        Raise the "Error" exception in case of error. 
        
        Note: The path is given as an argument rather than using self.filePath. 
        So this routine can be used for yWriter-generated xml files other than .yw7 as well. 
        '''
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        newlines = ['<?xml version="1.0" encoding="utf-8"?>']
        for line in lines:
            for tag in self._CDATA_TAGS:
                line = re.sub(f'\<{tag}\>', f'<{tag}><![CDATA[', line)
                line = re.sub(f'\<\/{tag}\>', f']]></{tag}>', line)
            newlines.append(line)
        text = '\n'.join(newlines)
        text = text.replace('[CDATA[ \n', '[CDATA[')
        text = text.replace('\n]]', ']]')
        text = unescape(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "{os.path.normpath(filePath)}".')

import tkinter as tk
from tkinter import messagebox
from tkinter import ttk


class CollectionManager(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')
    _SERIES_PREFIX = 'sr'
    _BOOK_PREFIX = 'bk'

    def __init__(self, title, ui, size, collection, **kw):
        self._ui = ui
        super().__init__(**kw)
        self.title(title)
        self.geometry(size)
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        #--- Main menu.
        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        #--- File menu.
        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        # self.fileMenu.add_command(label=_('Open...'), accelerator=self._KEY_OPEN_PROJECT[1], command=lambda: self.open_project(''))
        # self.fileMenu.add_command(label=_('Close'), command=self.close_project)
        # self.fileMenu.entryconfig(_('Close'), state='disabled')
        self.fileMenu.add_command(label=_('Exit'), accelerator=self._KEY_QUIT_PROGRAM[1], command=self.on_quit)

        #--- Series menu.
        self.seriesMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Series'), menu=self.seriesMenu)
        self.seriesMenu.add_command(label=_('Remove selected series from collection'), command=self._remove_series)

        #--- Book menu.
        self.bookMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Book'), menu=self.bookMenu)
        self.bookMenu.add_command(label=_('Update book data from current project'), command=self._update_book)
        self.bookMenu.add_command(label=_('Add current project to collection'), command=self._add_current_project)
        self.bookMenu.add_command(label=_('Remove selected book from collection'), command=self._remove_book)

        #--- Main window.
        self.mainWindow = ttk.Frame(self)
        self.mainWindow.pack(fill=tk.BOTH, padx=2, pady=2)
        self.collection = collection

        #--- Tree for book selection.
        columns = 'Title'
        self._tv = ttk.Treeview(self.mainWindow, columns=columns, show='headings', selectmode='browse')
        self._tv.column('Title', width=250, minwidth=120, stretch=False)
        self._tv.heading('Title', text=_('Title'), anchor='w')
        self._tv.pack(side=tk.LEFT, fill=tk.Y)
        self._tv.bind('<<TreeviewSelect>>', self._on_select_node)
        self._tv.bind('<<TreeviewSelect>>', self._on_select_node)
        self._tv.bind('<Double-1>', self._open_project)
        self._tv.bind('<Return>', self._open_project)
        self._tv.bind('<Delete>', self._remove_node)

        #--- Viewer window for the description.
        self._viewer = tk.Text(self.mainWindow, wrap='word')
        self._viewer.pack()

        self._build_tree()
        self.isOpen = True

    def _build_tree(self):
        self._reset_tree()
        for bkId in self.collection.books:
            item = f'{self._BOOK_PREFIX}{bkId}'
            columns = [self.collection.books[bkId].title]
            self._tv.insert('', tk.END, item, values=columns)

    def _reset_tree(self):
        """Clear the displayed tree."""
        for child in self._tv.get_children(''):
            self._tv.delete(child)

    def update_col_structure(self):
        """Iterate the tree and rebuild the sorted lists."""

        def serialize_tree(node, srId):
            """Recursive tree walker.
            """
            for childNode in self.tree.get_children(node):
                if childNode.startswith(self._BOOK_PREFIX):
                    bkId = childNode[2:]
                    self.collection.series[srId].srtBooks.append(bkId)
                else:
                    srId = childNode[2:]
                    self.collection.srtSeries.append(srId)
                    self.collection.series[srId].srtBooks = []
                    scnPos = serialize_tree(childNode, srId)
                    title, columns, nodeTags = self._set_chapter_display(srId)
                self.tree.item(childNode, text=title, values=columns, tags=nodeTags)
            return scnPos

        self.collection.srtSeries = []
        serialize_tree('', '')

    def _on_select_node(self, event=None):
        """View the selected element's description."""
        self._viewer.delete('1.0', tk.END)
        try:
            nodeId = self._tv.selection()[0]
            elemId = nodeId[2:]
            if nodeId.startswith(self._BOOK_PREFIX):
                desc = self.collection.books[elemId].desc
            elif nodeId.startswith(self._SERIES_PREFIX):
                desc = self.collection.series[elemId].desc
            if desc:
                self._viewer.insert(tk.END, desc)
        except IndexError:
            pass

    def _open_project(self, event=None):
        """Make the application open the selected book's project."""
        try:
            nodeId = self._tv.selection()[0]
            if nodeId.startswith(self._BOOK_PREFIX):
                bkId = nodeId[2:]
                self._ui.open_project(self.collection.books[bkId].filePath)
        except IndexError:
            pass

    def _add_current_project(self, event=None):
        novel = self._ui.ywPrj
        if novel is not None:
            try:
                bkId = self.collection.add_book(novel)
            except Error as ex:
                self._show_info(str(ex))
            else:
                if bkId is not None:
                    item = f'{self._BOOK_PREFIX}{bkId}'
                    columns = [self.collection.books[bkId].title]
                    self._tv.insert('', tk.END, item, values=columns)
                    self._show_info(f'"{novel.title}" added to the collection.')
                else:
                    self._show_info(f'!"{novel.title}" already exists.')

    def _update_book(self, event=None):
        novel = self._ui.ywPrj
        if novel is not None:
            for bkId in self.collection.books:
                if novel.title == self.collection.books[bkId].title:
                    self.collection.books[bkId].pull_metadata(novel)

    def _remove_book(self, event=None):
        try:
            nodeId = self._tv.selection()[0]
            elemId = nodeId[2:]
            message = ''
            try:
                if nodeId.startswith(self._BOOK_PREFIX):
                    message = self.collection.remove_book(elemId)
                    if self._tv.prev(nodeId):
                        self._tv.selection_set(self._tv.prev(nodeId))
                    elif self._tv.parent(nodeId):
                        self._tv.selection_set(self._tv.parent(nodeId))
                    self._build_tree()
            except Error as ex:
                self._show_info(str(ex))
            else:
                if message:
                    self._show_info(message)
        except IndexError:
            pass

    def _remove_series(self, event=None):
        try:
            nodeId = self._tv.selection()[0]
            elemId = nodeId[2:]
            message = ''
            try:
                if nodeId.startswith(self._SERIES_PREFIX):
                    message = self.collection.remove_series(elemId)
                    if self._tv.prev(nodeId):
                        self._tv.selection_set(self._tv.prev(nodeId))
                    elif self._tv.parent(nodeId):
                        self._tv.selection_set(self._tv.parent(nodeId))
                    self._build_tree()
            except Error as ex:
                self._show_info(str(ex))
            else:
                if message:
                    self._show_info(message)
        except IndexError:
            pass

    def _remove_node(self, event=None):
        try:
            nodeId = self._tv.selection()[0]
            if nodeId.startswith(self._SERIES_PREFIX):
                self._remove_series()
            elif nodeId.startswith(self._BOOK_PREFIX):
                self._remove_book()
        except IndexError:
            pass

    def _show_info(self, message):
        if message.startswith('!'):
            message = message.split('!', maxsplit=1)[1].strip()
            messagebox.showerror(message=message)
        else:
            messagebox.showinfo(message=message)
        self.lift()
        self.focus()

    def on_quit(self, event=None):
        try:
            self.collection.write()
        except Exception as ex:
            self._show_info(str(ex))
        finally:
            self.destroy()
            self.isOpen = False

APPLICATION = _('Collection')
DEFAULT_FILE = 'collection.pwc'


class Plugin:
    """novelyst collection manager plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.    
    """
    VERSION = '0.2.0'
    NOVELYST_API = '2.0'
    DESCRIPTION = 'A book/series collection manager'
    URL = 'https://peter88213.github.io/novelyst_collection'

    def install(self, ui):
        """Add a submenu to the 'File' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._collectionManager = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            installDir = f'{homeDir}/.pywriter/collection'
        except:
            installDir = '.'
        os.makedirs(installDir, exist_ok=True)
        filePath = f'{installDir}/{DEFAULT_FILE}'
        self.collection = Collection(filePath)

        # Create a submenu
        self._ui.fileMenu.insert_command(0, label=APPLICATION, command=self._start_manager)
        self._ui.fileMenu.insert_separator(1)
        self._ui.fileMenu.entryconfig(APPLICATION, state='normal')

    def _start_manager(self):
        if os.path.isfile(self.collection.filePath):
            self.collection.read()
        __, x, y = self._ui.root.geometry().split('+')
        offset = 300
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        if self._collectionManager:
            if self._collectionManager.isOpen:
                self._collectionManager.lift()
                self._collectionManager.focus()
                return

        self._collectionManager = CollectionManager(APPLICATION, self._ui, windowGeometry, self.collection)
